package Login_Page;

import java.awt.Window;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

import dev.failsafe.internal.util.Assert;

public class Login {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://app.logyxps.com/");
		
		driver.findElement(By.xpath("//input[@name=\"email\"]")).sendKeys("demomail@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("demomail");
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class=\"swal2-confirm swal2-styled\"]")).click();
		if (driver.findElement(By.xpath("//h1[contains(text(),\"Dashboard\")]")).isDisplayed()) {
			System.out.println("Login successfull and landed on dashboard");
			
		}else {
			System.out.println("Login failed to land on dashboard");
		}
		Thread.sleep(3000);
		driver.quit();
	}

}
